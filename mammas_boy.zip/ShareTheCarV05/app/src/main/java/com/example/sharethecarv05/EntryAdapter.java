package com.example.sharethecarv05;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

import java.util.Calendar;
import java.util.List;

public class EntryAdapter extends ArrayAdapter {

    private Context context;

    private View view;

    private LayoutInflater layoutInflater;

    private TextView endTime, startTime, textViewDay,user;
    private LinearLayout linearLayout,menubtn;

    private List<Entry> entries;
    private ImageView menu;
    Integer year,month,day,startHour,startMinute,endHour,endMinute,editYear,editMonth,editDay;
    Button btnDialogSaveChanges,editStarTime,editEndTime,editDate;
    Entry edit;
    Dialog dialog;
    String userName;

    public EntryAdapter(Context adapterContext, int xmlFileResource, int layoutResource,
                        List<Entry> entryLst,String userName) {
        super(adapterContext, xmlFileResource, layoutResource, entryLst);

        this.context = adapterContext;
        this.entries = entryLst;
        this.userName=userName;
    }

    public View getView(int position, View convertView, ViewGroup parent){
        this.layoutInflater = ((Activity)this.context).getLayoutInflater();

        this.view = layoutInflater.inflate(R.layout.entry, parent, false);

        this.startTime = (TextView)view.findViewById(R.id.textViewStartTime);
        this.user = (TextView)view.findViewById(R.id.textViewUser);
        this.linearLayout = (LinearLayout) view.findViewById(R.id.layout);
        this.menu = (ImageView) view.findViewById(R.id.btnEntryMenu);

        Entry entryObj = entries.get(position);

        //linearLayout.setBackgroundColor(Color.parseColor("#ffff00"));// TODO: 1/5/2024 make the kolers do stufe for difren stufe
        startTime.setText(entryObj.getDateRange().StartTimeToString()+" - "+entryObj.getDateRange().EndTimeToString());
        user.setText(entryObj.getUserName());

        if (userName.equals(entryObj.getUserName())){
            Car_Activity car_activity = (Car_Activity) context;
            int nightModeFlags = getContext().getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
            if(nightModeFlags == Configuration.UI_MODE_NIGHT_YES)
                menu.setImageResource(R.drawable.menunight);
            else
                menu.setImageResource(R.drawable.menu);
            PopupMenu popup = new PopupMenu(context, menu);
            popup.getMenuInflater().inflate(R.menu.entry_menu, popup.getMenu());
            popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem menuItem) {
                    int id=menuItem.getItemId();
                    if(R.id.editEntry == id){
                        car_activity.createEditEntryDialog(entryObj);
                    }
                    if(R.id.deleteEnty == id){
                        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                switch (which) {
                                    case DialogInterface.BUTTON_POSITIVE:
                                        ScheduleManager.DeleteEntry(entryObj);
                                        car_activity.updateListView();
                                        break;

                                    case DialogInterface.BUTTON_NEGATIVE:
                                        //No button clicked
                                        break;
                                }
                            }
                        };
                        AlertDialog.Builder builder = new AlertDialog.Builder(context);
                        builder.setMessage("Are you sure you want to delete this time slot?").setPositiveButton("Yes", dialogClickListener)
                                .setNegativeButton("No", dialogClickListener).show();
                    }

                    return false;
                }
            });
            menu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    popup.show();
                }
            });}
        return this.view;
    }
}
