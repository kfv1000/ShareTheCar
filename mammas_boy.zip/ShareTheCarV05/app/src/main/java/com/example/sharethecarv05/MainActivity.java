package com.example.sharethecarv05;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Date;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btnLogin,btnSignUp,btnDialogSignUp;
    String userName, password, vPasswrod;
    EditText etUserName,etPassword,etVPasswrod;
    EditText etLoginUserName,etLoginPassword;
    RadioButton rbKid,rbParent;
    Dialog dialog;
    HashMap<String, User> per;
    User user;

    public DatabaseReference myRef;
    public FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnLogin = findViewById(R.id.btnLogin);
        btnSignUp = findViewById(R.id.btnSignUp);
        btnLogin.setOnClickListener(this);
        btnSignUp.setOnClickListener(this);

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("Cars");
        myRef.child("Sup").setValue(new Car("sup","sup"));
        myRef = database.getReference("Users");
        myRef.child("hi").setValue(new Parent("hi","123"));
        myRef = database.getReference("Schedule");
        myRef.child("0").setValue(new Entry("mama mia","mama mia",new DateRange(2024,1,5,17,14,18,14)));
        myRef = database.getReference("Permissions");
        myRef.child("0").setValue(new CarUser("hi","sup"));


        user =new Parent("kfir","69");

        new UserManager();
        new CarManager();
        new PermissionManager();
        new ScheduleManager();

        UserManager.setNewUser(user);

        etLoginUserName=findViewById(R.id.etUserName);
        etLoginPassword=findViewById(R.id.etPassword);

        Intent intent = new Intent(this,MyService.class);
        startService(intent);

    }

    public void createSignUpDialog()
    {
        dialog = new Dialog(this);
        dialog.setContentView(R.layout.sin_up_dialog);
        //d.setTitle("pick a car");
        dialog.setCancelable(true);
        btnDialogSignUp= dialog.findViewById(R.id.btnDialogSignUp);
        btnDialogSignUp.setOnClickListener(this);
        dialog.show();
    }



    @Override
    public void onClick(View view) {
        if(view == btnLogin){
            Intent intent=new Intent(MainActivity.this,TimesActivity.class);
            User user1 = UserManager.getUser(etLoginUserName.getText().toString());
            if(user1==null){
                Toast.makeText(this, "Username does not exist", Toast.LENGTH_SHORT).show();
            }
            else if(user1.isPassword(etLoginPassword.getText().toString())){
                UserManager.setActiveUser(etLoginUserName.getText().toString());
                intent.putExtra("bili",user1);
                startActivity(intent);
            }
            else{
                Toast.makeText(this, "Password is incorrect", Toast.LENGTH_SHORT).show();
            }
        }
        if(view==btnSignUp){
            createSignUpDialog();
        }
        if(view==btnDialogSignUp){
            etUserName = dialog.findViewById(R.id.etUserName);
            etPassword = dialog.findViewById(R.id.etPassword);
            etVPasswrod = dialog.findViewById(R.id.etVPasswrod);
            userName = etUserName.getText().toString();
            password = etPassword.getText().toString();
            vPasswrod = etVPasswrod.getText().toString();
            rbKid= dialog.findViewById(R.id.rbKid);
            if(userName!=null&&password!=null&&vPasswrod!=null){
                if(password.equals(vPasswrod)) {
                    User user1;
                    if(rbKid.isChecked()){
                        user1 = new Kid(userName, password);
                    }
                    else {
                        user1 = new Parent(userName, password);
                    }
                    if(UserManager.setNewUser(user1)){
                        Toast.makeText(this, userName+" welcome", Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                    else
                        Toast.makeText(this, "User name already exists - try a different one", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                }
            }
            else{
                if(userName == null) Toast.makeText(this, "Username cannot be empty", Toast.LENGTH_SHORT).show();
                else if (password == null) Toast.makeText(this, "Password cannot be empty", Toast.LENGTH_SHORT).show();
                else if (vPasswrod == null) Toast.makeText(this, "Verify password cannot be empty", Toast.LENGTH_SHORT).show();
            }
        }
    }


}