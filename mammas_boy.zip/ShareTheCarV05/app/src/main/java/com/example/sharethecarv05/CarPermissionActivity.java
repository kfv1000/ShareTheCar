package com.example.sharethecarv05;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class CarPermissionActivity extends AppCompatActivity implements View.OnClickListener {
    ListView listView;
    Button btnAddUser,btnBack;
    EditText editTextUser;
    UserAdapter userAdapter;
    User user;
    Car car;
    String u;
    TextView title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_permission);

        Intent intent = getIntent();
        user = (User) intent.getSerializableExtra("bili");
        car = (Car) intent.getSerializableExtra("broooooom");

        listView = findViewById(R.id.listViewUsers);
        btnAddUser = findViewById(R.id.btnAddUser);
        editTextUser = findViewById(R.id.editTextUser);
        btnBack = findViewById(R.id.btnBack);
        title = findViewById(R.id.title);
        title.setText("Users that are allowed to use the "+car.getModel()+" car");

        DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                switch (which){
                    case DialogInterface.BUTTON_POSITIVE:
                        PermissionManager.RemovePermission(u,car.getId());
                        refresListView();
                        break;

                    case DialogInterface.BUTTON_NEGATIVE:
                        //No button clicked
                        break;
                }
            }
        };
        Context context = this;
        userAdapter = new UserAdapter(this, R.layout.user, R.id.carListViewLayout, UserManager.GetUsers(PermissionManager.GetCarUsersWifawtUser(car.getId(), user.getUsername())));
        listView.setAdapter(userAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                u = PermissionManager.GetCarUsersWifawtUser(car.getId(), user.getUsername()).get(position);
                builder.setMessage("Are you sure you want to delete "+u+"'s permission to use this car?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();
            }
        });

        btnAddUser.setOnClickListener(this);
        btnBack.setOnClickListener(this);


    }
    public void refresListView(){
        userAdapter = new UserAdapter(this, R.layout.user, R.id.carListViewLayout, UserManager.GetUsers(PermissionManager.GetCarUsersWifawtUser(car.getId(), user.getUsername())));
        listView.setAdapter(userAdapter);
    }
    @Override
    public void onClick(View view) {
        if(view == btnAddUser){
            String userName = editTextUser.getText().toString();
            User PermissionUser = UserManager.getUser(userName);
            if(PermissionUser == null){
                Toast.makeText(this, "User does not exist", Toast.LENGTH_SHORT).show();
            } else if (PermissionManager.UserHasCarPermission(userName,car.getId())) {
                Toast.makeText(this, "User already has permission", Toast.LENGTH_SHORT).show();
            }
            else{
                PermissionManager.SetNewPermission(userName,car.getId());
                userAdapter = new UserAdapter(this, R.layout.user, R.id.carListViewLayout, UserManager.GetUsers(PermissionManager.GetCarUsersWifawtUser(car.getId(), user.getUsername())));
                listView.setAdapter(userAdapter);
            }
        }
        if(view == btnBack){
            Intent intent = new Intent(CarPermissionActivity.this,Car_Activity.class);
            intent.putExtra("bili", user);
            intent.putExtra("broooooom",car);
            startActivity(intent);
        }
    }
}