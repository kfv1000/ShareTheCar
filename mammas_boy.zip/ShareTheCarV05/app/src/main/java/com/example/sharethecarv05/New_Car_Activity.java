package com.example.sharethecarv05;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
// Import necessary classes
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.ml.vision.text.FirebaseVisionTextRecognizer;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.PrivateKey;

public class New_Car_Activity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    Button btnCancel,btnAddCar,btnCarIdImge;
    EditText etCarNum;
    String carModel;
    User user;

    private static final int CAMERA_REQUEST_CODE = 1001;
    private static final int PERMISSION_REQUEST_CODE = 2000;
    private TextView textView;

    private static final int REQUEST_CAMERA_COME = 100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_car);

        btnCancel = findViewById(R.id.btnCancel);
        btnAddCar = findViewById(R.id.btnAddCar);
        etCarNum=findViewById(R.id.carnum);
        btnCarIdImge = findViewById(R.id.btnCarIdImge);

        btnCancel.setOnClickListener(this);
        btnAddCar.setOnClickListener(this);
        btnCarIdImge.setOnClickListener(this);

        Intent intent =getIntent();
        user = (User) intent.getSerializableExtra("bili");

        if(ContextCompat.checkSelfPermission(New_Car_Activity.this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(New_Car_Activity.this, new String[]{
                    Manifest.permission.CAMERA
            },100);
        }

        Spinner spinner = (Spinner) findViewById(R.id.spinnerCarModels);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.spinnerCarModels,
                android.R.layout.simple_spinner_item
        );
        // Specify the layout to use when the list of choices appears.
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner.
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

        FirebaseApp.initializeApp(this);


    }





    @Override
    public void onClick(View view) {
        if (btnCancel == view) {
            Intent intent = new Intent(New_Car_Activity.this, TimesActivity.class);
            intent.putExtra("bili", user);
            startActivity(intent);
        }
        if (btnAddCar == view) {
            //if(carImge == null)
            //Toast.makeText(this, "imge is mising", Toast.LENGTH_SHORT).show();
            if (etCarNum.getText().toString() == null)
                Toast.makeText(this, "Car license plate number cannot be empty", Toast.LENGTH_SHORT).show();
            else if (carModel == null||carModel.equals("Pick A Car Modle"))
                Toast.makeText(this, "Car model cannot be empty", Toast.LENGTH_SHORT).show();

            else {
                if (((Parent) user).CreateCar(carModel, etCarNum.getText().toString())) {
                    UserManager.Update(user);
                    Intent intent = new Intent(New_Car_Activity.this, TimesActivity.class);
                    intent.putExtra("bili", user);
                    startActivity(intent);
                } else
                    Toast.makeText(this, "Car license plate number already in use", Toast.LENGTH_SHORT).show();
            }

        }
        if(btnCarIdImge == view){
            checkPermissionsAndOpenCamera();
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        carModel = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    private void checkPermissionsAndOpenCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    PERMISSION_REQUEST_CODE);
        } else {
            openCamera();
        }
    }
    private void openCamera()
    {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            Uri imageUri = getImageUri(imageBitmap); // Save image to gallery and get URI
            if (imageUri != null) {
                startCropActivity(imageUri);
            } else {
                Toast.makeText(this, "Error saving image to gallery", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {
                Uri resultUri = result.getUri();
                processImage(resultUri);
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Exception error = result.getError();
                Toast.makeText(this, "Error cropping image: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Helper method to get a URI for a bitmap (assuming you have a helper method for saving the image)
    private Uri getImageUri(Bitmap imageBitmap) {
        String imageFileName = "OCR_Image_" + System.currentTimeMillis() + ".jpg";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File imageFile = new File(storageDir, imageFileName);

        try {
            FileOutputStream out = new FileOutputStream(imageFile);
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();

            // Add the image to the gallery (optional)
            Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
            Uri contentUri = Uri.fromFile(imageFile);
            mediaScanIntent.setData(contentUri);
            this.sendBroadcast(mediaScanIntent);

            return contentUri;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private void startCropActivity(Uri imageUri) {
        CropImage.activity(imageUri)
                .setGuidelines(CropImageView.Guidelines.ON) // Optional: Set a specific aspect ratio
                .start(this);
    }

    private void processImage(Uri imageUri) {
        try {
            FirebaseVisionImage image = FirebaseVisionImage.fromFilePath(this, imageUri);
            FirebaseVisionTextRecognizer textRecognizer = FirebaseVision.getInstance()
                    .getOnDeviceTextRecognizer();
            textRecognizer.processImage(image)
                    .addOnSuccessListener(new OnSuccessListener<FirebaseVisionText>() {
                        @Override
                        public void onSuccess(FirebaseVisionText text) {
                            displayTextFromImage(text);
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(New_Car_Activity.this, "Error recognizing text: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        } catch (IOException e) {
            Toast.makeText(this, "Error processing image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void displayTextFromImage(FirebaseVisionText text) {
        StringBuilder textBuilder = new StringBuilder();
        for (FirebaseVisionText.TextBlock block : text.getTextBlocks()) {
            textBuilder.append(block.getText());
            textBuilder.append("\n");
        }
        etCarNum.setText(textBuilder.toString());//end resolt
    }
}