package com.example.sharethecarv05;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class Time_seter_activity extends AppCompatActivity implements View.OnClickListener {
    Button date, startTime, endTime,btnSetTime,btnCancel;
    Integer year,month,day,startHour,startMinute,endHour,endMinute;
    private User user;
    private Car car;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_seter);

        Intent intent =getIntent();
        user = (User) intent.getSerializableExtra("bili");
        car = (Car) intent.getSerializableExtra("broooooom");

        date=findViewById(R.id.btnDate);
        startTime =findViewById(R.id.btnSTime);
        endTime =findViewById(R.id.btnETime);
        btnCancel=findViewById(R.id.btnCancel);
        btnSetTime=findViewById(R.id.btnSetTime);

        date.setOnClickListener(this);
        startTime.setOnClickListener(this);
        endTime.setOnClickListener(this);
        btnSetTime.setOnClickListener(this);
        btnCancel.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        if (btnCancel == view){
            Intent intent = new Intent(Time_seter_activity.this,Car_Activity.class);
            intent.putExtra("bili", user);
            intent.putExtra("broooooom",car);
            startActivity(intent);
        }
        if (btnSetTime == view){
            if (year==null)
                Toast.makeText(this, "impot the date", Toast.LENGTH_SHORT).show();
            else if (startHour == null)
                Toast.makeText(this, "impot the starting time", Toast.LENGTH_SHORT).show();
            else if (endHour == null)
                Toast.makeText(this, "impot the ending time", Toast.LENGTH_SHORT).show();
            else{
                DateRange dateRange = new DateRange(year,month,day,startHour,startMinute,endHour,endMinute);
                Integer resolt = ScheduleManager.AddEntry(user.getUsername(),car.getId(),dateRange);
                switch (resolt){
                    case 1:{
                        Toast.makeText(this, "you olredy have a time slot in the same time", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case 2:{
                        Toast.makeText(this, "car olredy in use at this time", Toast.LENGTH_SHORT).show();
                        break;
                    }
                    case 0:{
                        Intent intent = new Intent(Time_seter_activity.this,Car_Activity.class);
                        intent.putExtra("bili", user);
                        intent.putExtra("broooooom",car);
                        startActivity(intent);
                        break;
                    }

                }
            }
        }
        else if (view == date)
            showDatePicker();
        else if (startTime == view || endTime == view){
            final Calendar calendar = Calendar.getInstance();

            // on below line we are getting our hour, minute.
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            // on below line we are initializing our Time Picker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(Time_seter_activity.this,new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int hourOfDay,
                                      int minute) {
                    // on below line we are setting selected time
                    // in our text view.
                    if(endTime == view){
                        if((startHour != null && startHour > hourOfDay) || (startHour != null && startMinute > minute && startHour == hourOfDay))
                            Toast.makeText(Time_seter_activity.this, "the ending time you slekted is befor the start time", Toast.LENGTH_SHORT).show();
                        else{
                            endTime.setText(hourOfDay + ":" + minute);
                            endHour=hourOfDay;
                            endMinute=minute;
                        }
                    }
                    else{
                        if(endHour!=null && endHour < hourOfDay && endMinute < minute)
                            Toast.makeText(Time_seter_activity.this, "the starting time you slkted is after the ending time", Toast.LENGTH_SHORT).show();
                        else{
                            startTime.setText(hourOfDay + ":" + minute);
                            startHour=hourOfDay;
                            startMinute=minute;
                        }
                    }
                }
            }, hour, minute, false);
            // at last we are calling show to
            // display our time picker dialog.
            timePickerDialog.show();
        }

    }
    public void saveDate(Integer year,Integer month,Integer day){
        this.year = year;
        this.month = month;
        this.day = day;
    }
    private void showDatePicker() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                String selectedDate = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                date.setText(selectedDate);
                saveDate(year,monthOfYear+1,dayOfMonth);
            }
        }, year, month, day);

        datePickerDialog.show();
    }
}
