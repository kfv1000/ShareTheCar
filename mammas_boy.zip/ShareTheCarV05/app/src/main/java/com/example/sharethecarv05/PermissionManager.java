package com.example.sharethecarv05;

import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class PermissionManager {
    public static ArrayList<CarUser> carUsers;
    public static DatabaseReference myPermissionRef;

    public PermissionManager() {
        carUsers = new ArrayList<>();
        myPermissionRef = FirebaseDatabase.getInstance().getReference("Permissions");
        carUsers = GetHashMApOfPermissionsFromDB();
    }

    public static ArrayList<CarUser> GetHashMApOfPermissionsFromDB()
    {
        myPermissionRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                GenericTypeIndicator<ArrayList<CarUser>> t = new GenericTypeIndicator<ArrayList<CarUser>>() {
                };
                carUsers = (ArrayList<CarUser>) dataSnapshot.getValue(t);
            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("MyReadWriteDb", "Failed to read value.", error.toException());
            }
        });
        return carUsers;
    }
    public static ArrayList<String> GetUserCars(User user){
        ArrayList<String> carIds = new ArrayList<>();
        for (int i = 0; i < carUsers.size(); i++) {
            if(carUsers.get(i).getUserName().equals(user.getUsername()))
                carIds.add(carUsers.get(i).getCarId());
        }
        return carIds;
    }
    public static void SetNewPermission(String userName , String id){
        carUsers.add(new CarUser(userName,id));
        myPermissionRef.setValue(carUsers);
    }
    public static ArrayList<String> GetCarUsersWifawtUser(String carId,String userName){
        ArrayList<String> userNames = new ArrayList<>();
        for (int i = 0; i < carUsers.size(); i++) {
            if(carUsers.get(i).getCarId().equals(carId))
                if (!carUsers.get(i).getUserName().equals(userName))
                    userNames.add(carUsers.get(i).getUserName());
        }
        return userNames;
    }
    public static ArrayList<String> GetCarUsers(String carId){
        ArrayList<String> userNames = new ArrayList<>();
        for (int i = 0; i < carUsers.size(); i++) {
            if(carUsers.get(i).getCarId().equals(carId))
                userNames.add(carUsers.get(i).getUserName());
        }
        return userNames;
    }
    public static Boolean UserHasCarPermission(String userName,String carId){
        for (int i = 0; i < carUsers.size(); i++) {
            if(carUsers.get(i).getUserName().equals(userName)&&carUsers.get(i).getCarId().equals(carId))
                return true;
        }
        return false;
    }
    public static void RemovePermission(String userName,String carId){
        for (int i = 0; i < carUsers.size(); i++) {
            if(carUsers.get(i).getUserName().equals(userName)&&carUsers.get(i).getCarId().equals(carId)){
                carUsers.remove(i);
                myPermissionRef.setValue(carUsers);
            }
        }
    }
    public static void RemovePermission(String carId){
        for (int i = 0; i < carUsers.size(); i++) {
            if(carUsers.get(i).getCarId().equals(carId)){
                carUsers.remove(i);
                myPermissionRef.setValue(carUsers);
            }
        }
    }
}
