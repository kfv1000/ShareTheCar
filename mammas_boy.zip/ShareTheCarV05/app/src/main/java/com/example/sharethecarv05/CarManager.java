package com.example.sharethecarv05;

import android.util.Log;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class CarManager {
    public static DatabaseReference myCarRef;
    public static HashMap<String, Car> hscars;
    public CarManager(){
        myCarRef = FirebaseDatabase.getInstance().getReference("Cars");
        hscars = GetHashMApOfCarsFromDB();
    }
    public static HashMap<String, Car> GetHashMApOfCarsFromDB(){
        myCarRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                GenericTypeIndicator<HashMap<String, Car>> t = new GenericTypeIndicator<HashMap<String, Car>>() {
                };
                hscars = (HashMap<String, Car>) dataSnapshot.getValue(t);

            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w("MyReadWriteDb", "Failed to read value.", error.toException());

            }
        });
        return hscars;
    }
    public static Boolean setNewCar(Car car){
        if(hscars.get(car.getId())==null){
            hscars.put(car.getId(),car);
            myCarRef.child(car.getId()).setValue(car);
            return true;
        }
        else
            return false;
    }
    public static void UpdateCar(String temp,String model){
        myCarRef.child(temp).child("model").setValue(model);
        hscars = GetHashMApOfCarsFromDB();
    }


    public static ArrayList<Car> getCarsArray(ArrayList<String> carIds){
        ArrayList<Car> cars = new ArrayList<>();
        for (int i = 0; i < carIds.size(); i++) {
            if(hscars.get(carIds.get(i))!=null){
                if(hscars.get(carIds.get(i))!=null)
                    cars.add(hscars.get(carIds.get(i)));
            }
        }
        return cars;
    }
    public static void DeleteCar(Car car){
        hscars.remove(car.getId());
        myCarRef.setValue(hscars);
    }
}
