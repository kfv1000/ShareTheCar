package com.example.sharethecarv05;

import java.io.Serializable;

public class Parent extends User implements Serializable {


    public Parent(String username,String password){
        super(username,password,"Parent");
    }
    public Parent(User user){
        super(user.getUsername(),user.getPassword(),"Parent");
    }
    public Parent(){}

    public Boolean CreateCar(String model, String id){
        if(CarManager.setNewCar(new Car(id,model))) {
            PermissionManager.SetNewPermission(username,id);
            return true;
        }
        return false;
    }
}
