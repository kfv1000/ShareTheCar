package com.example.sharethecarv05;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

public class TimesActivity extends AppCompatActivity {

    User user;
    CarAdapter carAdapter;
    ListView listView;
    TextView textviewWelcomeMessage;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_times);

        Intent intent =getIntent();
        user = (User) intent.getSerializableExtra("bili");

        carAdapter = new CarAdapter(this, R.layout.car, R.id.carListViewLayout, CarManager.getCarsArray(PermissionManager.GetUserCars(user)));
        listView =findViewById(R.id.lvTimes);
        listView.setAdapter(carAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(TimesActivity.this,Car_Activity.class);
                intent.putExtra("bili", user);
                intent.putExtra("broooooom",CarManager.getCarsArray(PermissionManager.GetUserCars(user)).get(position));
                startActivity(intent);
            }
        });

        textviewWelcomeMessage = (TextView) findViewById(R.id.textviewWelcomeMessage);
        if(CarManager.getCarsArray(PermissionManager.GetUserCars(user)).isEmpty()){
            if(user.getClass()==Parent.class)
                textviewWelcomeMessage.setText("Use the menu to add new cars");//empty list parent
            else
                textviewWelcomeMessage.setText("Ask your parent to register their cars and give you permission to them");//empty list kid
        }
        else {
            if(user.getClass()==Parent.class)
                textviewWelcomeMessage.setText("");//not empty list parent
            else
                textviewWelcomeMessage.setText("");//not empty list kid
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        if(user.getClass()==Parent.class)
            getMenuInflater().inflate(R.menu.prent_main_menu,menu);
        else
            getMenuInflater().inflate(R.menu.kid_menu,menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        super.onOptionsItemSelected(item);
        int id = item.getItemId();
        if(R.id.logout == id){
            Intent intent = new Intent(TimesActivity.this,MainActivity.class);
            startActivity(intent);
        }
        if(R.id.edit_car == id){
            Intent intent = new Intent(TimesActivity.this,EditCar_Activity.class);
            intent.putExtra("bili", user);
            startActivity(intent);
        }
        if(R.id.new_car == id){
            Intent intent = new Intent(TimesActivity.this,New_Car_Activity.class);
            intent.putExtra("bili", user);
            startActivity(intent);
        }
        return true;
    }
}
